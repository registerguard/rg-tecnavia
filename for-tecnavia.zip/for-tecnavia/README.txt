Notes about "Top Header":
-------------------------

1.

Hopefully you can align the icons in their precise location over the background to match the background gradient.

2.

All of icons are located 15px down from the top of the background image.


3.

The gap between the navigation and the other icons is 15px.


Other note(s):
--------------

1.

Please contact Micky Hulse if have questions:

micky[at]registerguard.com

2.

PNG images have been optimized using PNGOUTWin:

http://www.ardfry.com/pngoutwin/

3.

See "example-layout.png" for a complete visual example.